let gameSeq=[];
let userSeq=[];

let btns=["yellow","orangered","purple","green"];

let strt=false;
let lev=0;

let h2=document.querySelector("h2");

document.addEventListener("keypress",function(){
    if(strt==false){
        console.log("Game Started");
        strt=true;

        levUp();
    }
});

function gameFlash(btn){
    btn.classList.add("flash");
    setTimeout(function(){
        btn.classList.remove("flash");
    },250);
}

function userFlash(btn){
    btn.classList.add("userflash");
    setTimeout(function(){
        btn.classList.remove("userflash");
    },250);
}

function levUp(){
    userSeq=[];
    lev++;
    h2.innerText=`Level ${lev}`;

    let randInx=Math.floor(Math.random()*3);
    let randColor=btns[randInx];
    let randbtn=document.querySelector(`.${randColor}`);
    gameSeq.push(randColor);
    console.log(gameSeq);
    gameFlash(randbtn);
}

function checkAns(inx){
    if(userSeq[inx]===gameSeq[inx]){
        if(userSeq.length==gameSeq.length){
            setTimeout(levUp,1000);
        }
    }else{
        h2.innerHTML=`Game Over! Your score was <b>${lev}</b>!<br>Press any key to start`;
        document.querySelector("body").style.backgroundColor="red";
        setTimeout(function(){
            document.querySelector("body").style.backgroundColor="white";
        },150)
        reset();
    }
}

function btnPress(){
    // console.log(this);
    let btn=this;
    userFlash(btn);

    userColor=btn.getAttribute("id");
    userSeq.push(userColor);

    checkAns(userSeq.length-1);
}
let allBtns=document.querySelectorAll(".btn");
for(btn of allBtns){
    btn.addEventListener("click",btnPress);
}

function reset(){
    strt=false;
    gameSeq=[];
    userSeq=[];
    lev=0;
}